def get_domain_people(lst: list, domain):
    match = [member for member in list if member.find(domain)]
    return match, len(match)

from __main__ import processed

name = "Aarav"
email = ""
phone = ""

def search_name(name, members):
    return list(filter(lambda member: member.name.lower() == name.lower(), members))

def search_phone(phone, members):
    return list(filter(lambda member: member.phone == phone, members))

def search_email(email, members):
    return list(filter(lambda member: member.email == email, members))