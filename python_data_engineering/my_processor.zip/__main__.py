from my_processor.core import process_members
from my_processor.data import raw_members

def main():
    members = process_members(raw_members)
    print(f"Summary: {len(members)} members processed successfully.")

if __name__ == "__main__":
    main()