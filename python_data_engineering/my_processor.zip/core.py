from my_processor.validator import validate_email, validate_name, validate_phone
from my_processor.InvalidMemberDataError import InvalidMemberDataError

class Member():
    """Member class contains the attributes for each member object created."""
    def __init__(self, name, email, phone):
        self.name = name
        self.email = email
        self.phone = phone

    def __str__(self):
        """__str__ is used when we're trying to print an object in our desirable format. 
            Here, a formatted string is printed whenever we try to print an object.
        """
        return f"name: {self.name}, email: {self.email}, phone: {self.email}"

def process_members(raw_members):
    for member in raw_members:
        # Processed is a list which stores all our processed, validated and created objects.
        processed = []
        
        try:
            name = validate_name(member.get("name"))
            phone = validate_phone(member.get("phone"), name)
            email = validate_email(member.get("email"), name)
            
            if all([name, phone, email]):
                member = Member(name, phone, email)
                processed.append(member)
                success_count += 1
                print(f"Processing member: {name}... Validation Successful.")
        
        except InvalidMemberDataError as e:
            print(f"Error: {e} Skipping.")
        
        except Exception as e:
            print(f"Unexpected Exception: {e}!")
    return processed