
class InvalidMemberDataError(Exception):
    pass

