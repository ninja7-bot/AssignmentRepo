import re
from my_processor.InvalidMemberDataError import InvalidMemberDataError

name_pattern = r"[a-zA-Z]"
def validate_name(name):
    if not name or None or not (re.match(name_pattern, name)):
        raise InvalidMemberDataError(f"Invalid name for member '{name}'.")
    return name.strip()

phone_pattern = r"[6-9]\d{9}"
def validate_phone(phone, name):
    if not phone or None or not (re.match(phone_pattern, phone)):
        raise InvalidMemberDataError(f"Invalid phone for member {name}.")
    return phone.strip()

email_pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"
def validate_email(email, name):
    if  not email or None or not (re.match(email_pattern, email)):
        raise InvalidMemberDataError(f"Invalid email for member {name}.")
    return email.strip()